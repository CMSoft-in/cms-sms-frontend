import "package:flutter/material.dart";

const laborPersonalInfo = 'Labor Personal Information';
const teamMember = "Team Member";
const rate = "Rate";
const laborName = 'Labor Name';
const deletelabor = "Delete Labor";
const rateModel = 'Rate Model';
const laborRate = 'Labour Rate';
const siteWorked = 'Sites Worked ';
const cuurentSiteAllocation = 'Current Site Allocation ';
const emergencyNumber1 = 'Emergency Contact 1';
const emergencyNumber2 = 'Emergency Contact 2';
const gPay = "Gpay Number";
const labordetails = "Enter the Labor Details";
const deleteLaborText='Deleted Labors';
const deleteLaborDetailsText="Deleted Labor Details";
const viewLaborDetailsText = "View Labor Details";
const editLaborDetailsText = "Edit Labor Details";

const laborpage1 = 'Page 1 of 6';
const laborpage2 = 'Page 2 of 6';
const laborpage3 = 'Page 3 of 6';
const laborpage4 = 'Page 4 of 6';
const laborpage5 = 'Page 5 of 6';
const laborpage6 = 'Page 6 of 6';

//
class LaborTextEditingController{
    final TextEditingController laborCategoryController = TextEditingController();
final TextEditingController rateModelController = TextEditingController();
final TextEditingController laborRateController = TextEditingController();
final TextEditingController siteWorkedController = TextEditingController();
final TextEditingController cuurentSiteAllocationController =
    TextEditingController();
final TextEditingController teamMemberController = TextEditingController();
final TextEditingController rateController = TextEditingController();
final TextEditingController gpayNumberController = TextEditingController();
final TextEditingController firstNameController = TextEditingController();
final TextEditingController lastNameController = TextEditingController();
final TextEditingController phoneNumberController = TextEditingController();
final TextEditingController addressline1Controller = TextEditingController();
final TextEditingController addressline2Controller =
    TextEditingController();
final TextEditingController cityController = TextEditingController();
final TextEditingController pincodeController = TextEditingController();
final TextEditingController stateController = TextEditingController();
final TextEditingController bloodGroupController =
    TextEditingController();
final TextEditingController aadharfilePathController =
    TextEditingController();
    final TextEditingController secondaryWhatsappController = TextEditingController();
final TextEditingController primaryNameController = TextEditingController();
final TextEditingController primaryPhoneNumberController = TextEditingController();
final TextEditingController primaryEmailController = TextEditingController();
final TextEditingController primaryWhatsappController = TextEditingController();
final TextEditingController secondaryNameController = TextEditingController();
final TextEditingController secondaryPhoneNumberController = TextEditingController();
final TextEditingController secondaryEmailController = TextEditingController();
final TextEditingController aadharNumberController = TextEditingController();
final TextEditingController accountNameController = TextEditingController();
final TextEditingController accountNumberController = TextEditingController();
final TextEditingController accountTypeController = TextEditingController();
final TextEditingController bankLocationController = TextEditingController();
final TextEditingController bankNameController = TextEditingController();
final TextEditingController ifscCodeController = TextEditingController();
}
